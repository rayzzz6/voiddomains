import "server-only";
import { isIPv4, isIPv6 } from "node:net";

const CF = "https://api.cloudflare.com/client/v4";

export const LABEL_RE = /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/;
export const RESERVED = new Set([
  "www", "mail", "admin", "api", "ns1", "ns2", "ftp", "smtp", "root",
  "support", "dashboard", "login", "billing", "status",
]);
const HOST_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/;

export type Rec = {
  type: "A" | "AAAA" | "CNAME" | "SRV";
  name: string;
  content?: string;
  data?: Record<string, unknown>;
};

export class DnsError extends Error {
  constructor(public code: "exists" | "rate_limited" | "provider") {
    super(code);
  }
}

function privateV4(ip: string) {
  const [a, b] = ip.split(".").map(Number);
  return a === 0 || a === 10 || a === 127 || a >= 224 ||
    (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
}

/** Returns an error message, or null when the target is valid for the record type. */
export function checkTarget(type: string, target: string): string | null {
  switch (type) {
    case "A":
      return isIPv4(target) && !privateV4(target) ? null : "Enter a public IPv4 address";
    case "AAAA":
      return isIPv6(target) && !/^(::1?$|f[cd]|fe[89ab])/i.test(target) ? null : "Enter a public IPv6 address";
    case "CNAME":
      return HOST_RE.test(target) ? null : "Enter a valid hostname";
    case "MINECRAFT":
      return checkTarget(isIPv4(target) ? "A" : isIPv6(target) ? "AAAA" : "CNAME", target);
    default:
      return "Unsupported record type";
  }
}

/** Records to create. Minecraft Java on a custom port needs an SRV record. */
export function plan(fqdn: string, type: string, target: string, port?: number): Rec[] {
  if (type !== "MINECRAFT") return [{ type: type as Rec["type"], name: fqdn, content: target }];
  const base = isIPv4(target) ? "A" : isIPv6(target) ? "AAAA" : "CNAME";
  if (!port || port === 25565) return [{ type: base, name: fqdn, content: target }];
  const recs: Rec[] = [];
  if (base !== "CNAME") recs.push({ type: base, name: fqdn, content: target });
  recs.push({
    type: "SRV",
    name: `_minecraft._tcp.${fqdn}`,
    data: {
      service: "_minecraft", proto: "_tcp", name: fqdn,
      priority: 0, weight: 5, port, target: base === "CNAME" ? target : fqdn,
    },
  });
  return recs;
}

async function cf(path: string, init: RequestInit = {}) {
  let res: Response;
  try {
    res = await fetch(CF + path, {
      ...init,
      cache: "no-store",
      headers: {
        Authorization: `Bearer ${process.env.CLOUDFLARE_API_TOKEN}`,
        "Content-Type": "application/json",
      },
    });
  } catch {
    throw new DnsError("provider");
  }
  const json = await res.json().catch(() => null);
  if (res.status === 429) throw new DnsError("rate_limited");
  if (!res.ok || !json?.success) {
    console.error("cloudflare error", res.status, JSON.stringify(json?.errors));
    const c = json?.errors?.[0]?.code;
    throw new DnsError(c === 81053 || c === 81057 || c === 81058 ? "exists" : "provider");
  }
  return json.result;
}

export async function createRecord(zoneId: string, r: Rec): Promise<string> {
  const body = {
    type: r.type, name: r.name, ttl: 300, proxied: false,
    ...(r.type === "SRV" ? { data: r.data } : { content: r.content }),
  };
  const out = await cf(`/zones/${zoneId}/dns_records`, { method: "POST", body: JSON.stringify(body) });
  return out.id as string;
}

export async function deleteRecord(zoneId: string, id: string) {
  await cf(`/zones/${zoneId}/dns_records/${id}`, { method: "DELETE" });
}
