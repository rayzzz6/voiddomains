import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { isIP } from "node:net";
import { z } from "zod";
import { createServerClient } from "@supabase/ssr";
import { createClient } from "@supabase/supabase-js";
import { checkTarget, createRecord, deleteRecord, DnsError, LABEL_RE, plan, RESERVED } from "@/lib/dns";

export const runtime = "nodejs";

const MAX_PER_USER = 5;
const MAX_PER_HOUR = 10;

const Input = z.object({
  label: z.string().trim().toLowerCase().min(1).max(63),
  domainId: z.string().uuid(),
  type: z.enum(["A", "AAAA", "CNAME", "MINECRAFT"]),
  target: z.string().trim().toLowerCase().min(1).max(253),
  port: z.number().int().min(1).max(65535).optional(),
});

const fail = (status: number, error: string) => NextResponse.json({ error }, { status });

export async function POST(req: Request) {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const store = await cookies();
  const authClient = createServerClient(url, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: { getAll: () => store.getAll(), setAll: () => {} },
  });
  const { data: { user } } = await authClient.auth.getUser();
  if (!user) return fail(401, "Sign in to create a subdomain");

  // Service role: server only. Every query below is scoped by the verified user id.
  const db = createClient(url, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } });

  const { data: profile } = await db.from("profiles").select("suspended").eq("id", user.id).single();
  if (!profile || profile.suspended) return fail(403, "This account cannot create subdomains");

  const since = new Date(Date.now() - 3_600_000).toISOString();
  const { count: attempts } = await db.from("audit_logs")
    .select("id", { count: "exact", head: true })
    .eq("user_id", user.id).eq("action", "create_attempt").gte("created_at", since);
  if ((attempts ?? 0) >= MAX_PER_HOUR) return fail(429, "Too many attempts. Try again in an hour.");
  await db.from("audit_logs").insert({ user_id: user.id, action: "create_attempt" });

  const parsed = Input.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return fail(400, "Check the form: some fields are invalid");
  const { label, domainId, type, target } = parsed.data;
  const port = type === "MINECRAFT" ? parsed.data.port : undefined;

  if (!LABEL_RE.test(label) || label.startsWith("xn--") || RESERVED.has(label)) {
    return fail(400, "That hostname is not allowed. Use letters, numbers and hyphens.");
  }
  const bad = checkTarget(type, target);
  if (bad) return fail(400, bad);

  const { data: domain } = await db.from("domains")
    .select("id,suffix,cf_zone_id").eq("id", domainId).eq("enabled", true).single();
  if (!domain) return fail(400, "That domain is not available");
  if (!isIP(target) && (target === domain.suffix || target.endsWith("." + domain.suffix))) {
    return fail(400, "The destination cannot point back to this domain");
  }

  const { count: owned } = await db.from("subdomains")
    .select("id", { count: "exact", head: true }).eq("user_id", user.id);
  if ((owned ?? 0) >= MAX_PER_USER) return fail(403, `Limit reached: ${MAX_PER_USER} subdomains per account`);

  const fqdn = `${label}.${domain.suffix}`;

  // Reserve the name first. The unique constraint settles races between users.
  const { data: row, error: insErr } = await db.from("subdomains")
    .insert({ user_id: user.id, domain_id: domain.id, label, type, target, port, status: "pending" })
    .select("id").single();
  if (insErr || !row) {
    return insErr?.code === "23505" ? fail(409, "That name is already taken") : fail(500, "Could not create the subdomain");
  }

  const made: string[] = [];
  try {
    for (const rec of plan(fqdn, type, target, port)) made.push(await createRecord(domain.cf_zone_id, rec));
  } catch (e) {
    await Promise.allSettled(made.map((id) => deleteRecord(domain.cf_zone_id, id)));
    await db.from("subdomains").delete().eq("id", row.id);
    const code = e instanceof DnsError ? e.code : "provider";
    await db.from("audit_logs").insert({ user_id: user.id, action: "create_failed", detail: { fqdn, code } });
    if (code === "exists") return fail(409, "That name is already in use");
    return fail(code === "rate_limited" ? 503 : 502, "The DNS provider is unavailable. Try again shortly.");
  }

  // Only reached after Cloudflare confirmed every record.
  await db.from("subdomains").update({ status: "active", cf_record_ids: made }).eq("id", row.id);
  await db.from("audit_logs").insert({ user_id: user.id, action: "create_ok", detail: { fqdn, type } });
  return NextResponse.json({ id: row.id, hostname: fqdn }, { status: 201 });
}
