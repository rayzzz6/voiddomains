"use client";
import { useEffect, useState } from "react";
import { createBrowserClient } from "@supabase/ssr";

type Domain = { id: string; suffix: string };

const field =
  "w-full rounded-lg border border-white/10 bg-neutral-900 px-3 py-3 text-base text-white placeholder-white/30 outline-none focus:border-violet-500 focus-visible:ring-2 focus-visible:ring-violet-500/40";

export default function CreatePage() {
  const [domains, setDomains] = useState<Domain[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [f, setF] = useState({ label: "", domainId: "", type: "MINECRAFT", target: "", port: "" });
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const sb = createBrowserClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    );
    sb.from("domains").select("id,suffix").eq("enabled", true).then(({ data }) => {
      setDomains(data ?? []);
      if (data?.[0]) setF((p) => ({ ...p, domainId: data[0].id }));
      setLoaded(true);
    });
  }, []);

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setF((p) => ({ ...p, [k]: e.target.value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    const res = await fetch("/api/subdomains", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...f, port: f.port ? Number(f.port) : undefined }),
    });
    const j = await res.json().catch(() => ({}));
    setMsg(
      res.ok
        ? { ok: true, text: `Created ${j.hostname}. The record is live in Cloudflare; it can take a few minutes to reach every resolver.` }
        : { ok: false, text: j.error ?? "Something went wrong. Try again." },
    );
    setBusy(false);
  }

  return (
    <main className="min-h-screen bg-black px-4 py-10 text-white">
      <form onSubmit={submit} className="mx-auto max-w-md space-y-5">
        <h1 className="text-2xl font-semibold tracking-tight">Create a subdomain</h1>

        {loaded && domains.length === 0 ? (
          <p className="rounded-lg border border-white/10 bg-neutral-900 p-4 text-white/70">
            No domains are enabled yet. An administrator must connect and enable one first.
          </p>
        ) : (
          <>
            <div className="flex gap-2">
              <input className={field} placeholder="play" value={f.label} onChange={set("label")}
                required autoCapitalize="none" autoCorrect="off" spellCheck={false} aria-label="Hostname" />
              <select className={field + " max-w-[55%]"} value={f.domainId} onChange={set("domainId")}
                required aria-label="Domain">
                {domains.map((d) => <option key={d.id} value={d.id}>.{d.suffix}</option>)}
              </select>
            </div>

            <select className={field} value={f.type} onChange={set("type")} aria-label="Use for">
              <option value="MINECRAFT">Minecraft server</option>
              <option value="A">Website or server (IPv4 address)</option>
              <option value="AAAA">Website or server (IPv6 address)</option>
              <option value="CNAME">Website (hostname)</option>
            </select>

            <input className={field} placeholder={f.type === "CNAME" ? "site.example.net" : "IP address or hostname"}
              value={f.target} onChange={set("target")} required autoCapitalize="none" autoCorrect="off"
              spellCheck={false} aria-label="Destination" />

            {f.type === "MINECRAFT" && (
              <div className="space-y-2">
                <input className={field} type="number" inputMode="numeric" min={1} max={65535}
                  placeholder="Port (leave empty for 25565)" value={f.port} onChange={set("port")} aria-label="Port" />
                <p className="text-sm text-white/50">
                  A custom port adds an SRV record, so Java Edition players connect with the hostname alone.
                </p>
              </div>
            )}

            <button disabled={busy || !f.domainId}
              className="w-full rounded-lg bg-violet-600 py-3 font-medium text-white hover:bg-violet-500 disabled:opacity-50">
              {busy ? "Creating" : "Create subdomain"}
            </button>
          </>
        )}

        {msg && <p role="status" className={msg.ok ? "text-violet-300" : "text-red-400"}>{msg.text}</p>}
      </form>
    </main>
  );
}
