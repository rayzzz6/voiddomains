# VoidDomains: core subdomain flow

Included: Supabase schema with row level security, server-only Cloudflare client, `POST /api/subdomains`, mobile-first Create page.
Not built yet: Home search, Dashboard, Login/Register, Documentation, Admin Dashboard, logo and favicon.

## Admin setup checklist (required before anyone can create a subdomain)
1. Own a domain and add it to Cloudflare. The zone must show Active. Copy its Zone ID (zone Overview page).
2. Cloudflare > My Profile > API Tokens > Create Token. Permission: Zone, DNS, Edit. Limit it to that zone only.
3. Supabase: create a project, open SQL Editor, run `supabase/schema.sql`.
4. Register in the app, then promote yourself (user id is in Authentication > Users):
   `update profiles set role = 'admin' where id = '<your user id>';`
5. Add the domain and enable it once the zone is Active:
   `insert into domains (suffix, cf_zone_id) values ('example.com', '<zone id>');`
   `update domains set enabled = true where suffix = 'example.com';`
6. Fill in the variables from `.env.example` locally (`.env.local`) and in Vercel. The service role key and Cloudflare token are server-only.

## Set up from an Android phone
1. Create a GitHub repo and open it in GitHub Codespaces from Chrome (desktop site mode).
2. In the Codespaces terminal:
   `npx create-next-app@latest voiddomains --ts --tailwind --app --src-dir --import-alias "@/*"`
   `cd voiddomains && npm i @supabase/supabase-js @supabase/ssr zod server-only`
3. Upload `src/`, `supabase/` and `.env.example` from this zip into the project, then copy `.env.example` to `.env.local` and fill it in.
4. `npm run dev`, open the forwarded port, test. Commit and push.
5. vercel.com > Add New > Project > import the repo > add the env vars > Deploy.

## Behaviour notes
- Success is returned only after Cloudflare confirms every record. A failure removes any records already created and releases the reserved name.
- Users can only read their own rows (RLS). Every write goes through server routes that use the verified user id.
- Limits: 5 subdomains per account, 10 attempts per hour (constants at the top of the route).
- Minecraft Java: a custom port creates a `_minecraft._tcp.<name>` SRV record (plus A/AAAA when the destination is an IP). Port 25565 needs no SRV. Bedrock ignores SRV.
- Domain ownership check is manual for now: enable a domain only after its zone is Active in your own Cloudflare account.
- Not run against live Supabase or Cloudflare. Test with a throwaway domain first.
