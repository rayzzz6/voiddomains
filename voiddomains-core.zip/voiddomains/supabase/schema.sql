create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  role text not null default 'user' check (role in ('user','admin')),
  suspended boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.domains (
  id uuid primary key default gen_random_uuid(),
  suffix text not null unique check (suffix ~ '^[a-z0-9.-]+\.[a-z]{2,}$'),
  cf_zone_id text not null,
  enabled boolean not null default false, -- flip on only after the zone is Active in Cloudflare
  created_at timestamptz not null default now()
);

create table public.subdomains (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  domain_id uuid not null references public.domains,
  label text not null check (label ~ '^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$'),
  type text not null check (type in ('A','AAAA','CNAME','MINECRAFT')),
  target text not null,
  port int check (port between 1 and 65535),
  cf_record_ids text[] not null default '{}',
  status text not null default 'pending' check (status in ('pending','active','suspended')),
  created_at timestamptz not null default now(),
  unique (domain_id, label)
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users on delete set null,
  action text not null,
  detail jsonb,
  created_at timestamptz not null default now()
);
create index on public.audit_logs (user_id, action, created_at desc);

-- Profile row on signup
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin insert into public.profiles (id) values (new.id); return new; end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Row level security
alter table public.profiles enable row level security;
alter table public.domains enable row level security;
alter table public.subdomains enable row level security;
alter table public.audit_logs enable row level security;

create policy "read own profile" on public.profiles for select using (id = auth.uid());
create policy "read enabled domains" on public.domains for select using (enabled);
create policy "read own subdomains" on public.subdomains for select using (user_id = auth.uid());
-- No insert/update/delete policies anywhere: every write goes through server routes
-- (service role) that check the signed-in user. audit_logs has no policies: no client access.
